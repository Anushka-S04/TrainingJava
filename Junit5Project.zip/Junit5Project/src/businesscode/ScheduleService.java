package businesscode;

public class ScheduleService {
	
	public boolean doSchedule() {
		//TODO: put logic here
		return true;
		}

		public boolean backupCalendar() {
		// TODO: put logic here
		return true;
		}

}
