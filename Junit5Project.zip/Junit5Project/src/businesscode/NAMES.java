package businesscode;

public enum NAMES {
	KK,PK,MK
}
