document.writeln("Hello World from Java Script");
document.writeln("<h1>Hello World from Java Script");
/* Java Script code to add 2 nos */

var a,b,sum;
var name=prompt("Enter Your Name :");
 a=parseInt(prompt("Enter first Number:","Enter a Number"));
 b=parseInt(prompt("Enter second Number:","Enter a Number"));
sum=a+b;
document.write("<br>"+"Hello "+name+"<br>");
document.writeln("The Addition of 2 nos is :"+sum);
alert("Thank You "+name);

// Ctrl + / = Single line comment

// Select multiple lines -  Alt+ Shift + a = Multi line comments

