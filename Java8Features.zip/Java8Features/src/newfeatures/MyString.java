package newfeatures;

@FunctionalInterface
public interface MyString {
	
	String MyStringFunction(String str);

}
