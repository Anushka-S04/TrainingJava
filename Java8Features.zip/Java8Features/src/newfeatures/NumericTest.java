package newfeatures;

@FunctionalInterface
public interface NumericTest {
	
	boolean computeTest(int n);

}
