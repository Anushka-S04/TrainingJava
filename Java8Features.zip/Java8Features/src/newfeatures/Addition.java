package newfeatures;


public interface Addition {
	
	int calculate(int a, int b);

}
