package com.coforge.training.mockitodemo;

public interface StockService {
	
	public double getPrice(Stock stock);

}
