package com.coforge.training.mockitodemo;

public interface IDemo {
	
	String S="Hello World"; // by default its final or a constant
	String greet(); //by default abstract
	
	

}
